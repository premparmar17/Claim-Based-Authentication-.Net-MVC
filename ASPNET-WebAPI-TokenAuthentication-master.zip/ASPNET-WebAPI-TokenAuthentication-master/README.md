# AspNetSimpleWebApiTokenAuthentication
Simplest way to send a token and secure a resource in Asp.Net WebAPI

See a full readme here

http://offering.solutions/2015/10/03/token-authentication-with-claims-and-asp-net-webapi-simple-example-also-on-github/
